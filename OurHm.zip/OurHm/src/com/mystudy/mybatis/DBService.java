package com.mystudy.mybatis;

import java.io.IOException;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

// mybatis 사용해서 작업할 SqlSession을 만들어줄 SqlSessionFactoty 객체 생성을 위한 클래스
public class DBService { 
	private static SqlSessionFactory factory;

	static {
		try {
			factory = new SqlSessionFactoryBuilder().build(Resources.getResourceAsReader("com/mystudy/mybatis/config.xml"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static SqlSessionFactory getFactory() {
		return factory;
	}
}
