package com.mystudy.vo;

public class CartVO {
	
	private int productNo;
	private String productName;
	private String thumnail;
	private int optionSize;
	private int amount;
	
	public CartVO() {
	}

	public CartVO(int productNo, String productName, String thumnail, int optionSize, int amount) {
		this.productNo = productNo;
		this.productName = productName;
		this.thumnail = thumnail;
		this.optionSize = optionSize;
		this.amount = amount;
	}
	
	public int getProductNo() {
		return productNo;
	}
	public void setProductNo(int productNo) {
		this.productNo = productNo;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getThumnail() {
		return thumnail;
	}
	public void setThumnail(String thumnail) {
		this.thumnail = thumnail;
	}
	public int getOptionSize() {
		return optionSize;
	}
	public void setOptionSize(int optionSize) {
		this.optionSize = optionSize;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "CartVO [productNo=" + productNo + ", productName=" + productName + ", thumnail=" + thumnail
				+ ", optionSize=" + optionSize + ", amount=" + amount + "]";
	}
	
	
	
} //end
